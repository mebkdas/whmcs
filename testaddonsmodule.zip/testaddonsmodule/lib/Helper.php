<?php

namespace WHMCS\Module\Addon\TestAddonsModule;

use WHMCS\Database\Capsule;
use WHMCS\User\Client;

class Helper
{

    public function testMethod()
    {

        $command = 'GetClients';

        //$adminUsername = 'ADMIN_USERNAME';

        $results = localAPI($command, []);

        // echo "<pre>";
        // print_r($results);

        // die();

        return $results;
    }

    public function saveClient($data)
    {

        $result = Capsule::table('tblclients')->insert($data);

        return $result;
    }

    public function statusUpdate($id)
    {
        try {
            $client = Client::findOrFail($id);

            $client->status = ($client->status == 'Active') ? 'Inactive' : 'Active';
            $client->save();

            return $client;
        } catch (\Exception $e) {
            echo "Uh oh. I couldn't update John Doe's address. {$e->getMessage()}";
        }
    }

    public function clientsDelete($ids){

        foreach ($ids as $id){
            try {
                Client::findOrFail($id)->delete();
            } catch (Exception $e) {
                echo "Uh oh. I couldn't delete John Doe's client record. {$e->getMessage()}";
            }
        }

    }
}
