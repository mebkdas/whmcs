<?php

namespace WHMCS\Module\Addon\TestAddonsModule\Admin;

use WHMCS\Module\Addon\TestAddonsModule\Helper;
use WHMCS\Smarty;
use WHMCS\User\Client;

class Controller
{

    public $tplFileName;
    public $smarty;
    public $tplVar = array();


    public function __construct($params)
    {
        global $CONFIG;

        $this->params = $params;
        $this->tplVar['rootURL'] = $CONFIG["SystemURL"];
        $this->tplVar['urlPath'] = $CONFIG["SystemURL"] . "/modules/addons/{$params['module']}/";
        $this->tplVar['_lang'] = $params["_lang"];
        $this->tplVar['moduleLink'] = $params['modulelink'];
        $this->tplVar['module'] = $params['module'];
        $this->tplVar['tplDIR'] = ROOTDIR . "/modules/addons/{$params['module']}/templates/admin/";
        $this->tplVar['header'] = ROOTDIR . "/modules/addons/{$params['module']}/templates/admin/header.tpl";
        $this->tplVar['footer'] = ROOTDIR . "/modules/addons/{$params['module']}/templates/admin/footer.tpl";
    }

    public function dasboard()
    {
        $testobj = new Helper();
        $clients = $testobj->testMethod();

        if ($clients) {
            $this->tplVar['clients'] = $clients['clients']['client'];
        }

        $this->tplFileName = __FUNCTION__;
        $this->output();
    }
    public function fileNotFound()
    {
        $this->tplFileName = __FUNCTION__;
        $this->output();
    }

    public function status()
    {
        if (isset($_GET['id'])) {
            $client_id = $_GET['id'];
            $testobj = new Helper();
            $clients = $testobj->statusUpdate($client_id);
            if ($clients) {
                $this->dasboard();
            }
        }
    }

    public function clientAdd()
    {
        $data = array();
        if (isset($_POST['token'])) {
            $data['firstName'] = $_POST['firstName'];
            $data['lastName'] = $_POST['lastName'];
            $data['email'] = $_POST['email'];
            $data['password'] = $_POST['password'];
            $data['address1'] = $_POST['address1'];
            $data['address2'] = $_POST['address2'];
            $data['phonenumber'] = "+".$_POST['country-calling-code-phonenumber'] . "." . $_POST['phonenumber'];
            $data['country'] = $_POST['country'];
            $data['city'] = $_POST['city'];
            $data['state'] = $_POST['state'];
            $data['postcode'] = $_POST['zip'];

            // $testobj = new Helper();
            // $respone = $testobj->saveClient($data);
            // if($respone){
            //     $this->dasboard();
            // }
            // die();

            $newClient = new Client;

            $newClient->firstName = $_POST['firstName'];
            $newClient->lastName = $_POST['lastName'];
            $newClient->email = $_POST['email'];
            $newClient->address1 = $_POST['address1'];
            $newClient->address2 = $_POST['address2'];
            $newClient->city = $_POST['city'];
            $newClient->state = $_POST['state'];
            $newClient->country = $_POST['country'];
            $newClient->phonenumber = "+".$_POST['country-calling-code-phonenumber'] . "." . $_POST['phonenumber'];
            $newClient->password = $_POST['password'];

            try {
                $newClient->save();
                $this->dasboard();
            } catch (Exception $e) {
                echo "Uh oh. I couldn't create John Doe's client record. {$e->getMessage()}";
            }
        }
    }

    public function ajax()
    {
        $action = (isset($_POST["ajaxAction"])?$_POST["ajaxAction"]:false);

        switch ($action)
        {
            case "getClientDetails":
                if(isset($_POST["client_id"]))  
                {    $clientId = $_POST["client_id"];
                //echo $clientId; die();

                $data = Client::findOrFail($clientId);

                echo json_encode($data);  
                }  
            break;
            default:
                echo "Not found";
        }
        exit;
    }

    public function clientDelete()
    {

        $selectedclients = $_POST['selectedclients'];
        $testobj = new Helper();
        $clients = $testobj->clientsDelete($selectedclients);
        $this->dasboard();
    }

    public function output()
    {
        $this->smarty = new Smarty();
        $this->smarty->assign('tplVar', $this->tplVar);

        if (!empty($this->tplFileName)) {
            $this->smarty->display($this->tplVar['tplDIR'] . $this->tplFileName . '.tpl');
        } else {
            $this->templateVar['errorMsg'] = 'not found';

            $this->smarty->display($this->tplDIR . 'error.tpl');
        }
    }
}
