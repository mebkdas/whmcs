<?php

namespace WHMCS\Module\Addon\TestAddonsModule\Client;


class ClientDispatcher {

    public function dispatch($action, $parameters)
    {
        $controller = new Controller($parameters);

        if (is_callable(array($controller, $action))) {
            return $controller->$action();
        }
    }
}