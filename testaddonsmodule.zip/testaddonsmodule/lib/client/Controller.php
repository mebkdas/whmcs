<?php

namespace WHMCS\Module\Addon\TestAddonsModule\Client;

use WHMCS\Smarty;

class Controller {

    public $tplFileName;
    public $smarty;
    public $tplVar = array();


    public function __construct($params)
    {   
        //echo "<pre>";
        //print_r($params);die;
        global $CONFIG;

        $this->params = $params;
        $this->tplVar['moduleLink'] = $params['modulelink'];
        $this->tplVar['module'] = $params['module'];
        $this->tplVar['tplDIR'] = ROOTDIR . "/modules/addons/{$params['module']}/templates/client/";
        //echo $this->tplVar['module']; die;
    }

    public function dashboard(){
        
        return array(
            'pagetitle' => 'Sample Addon Module',
            'breadcrumb' => array(
                'index.php?m=addonmodule' => 'Test Addon Module',
            ),
            'templatefile' => 'client/dashboard',
            'requirelogin' => false,
            'forcessl' => false,           
        );
    
    }

}