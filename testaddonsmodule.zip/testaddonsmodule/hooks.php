<?php

use WHMCS\View\Menu\Item as MenuItem;
use WHMCS\Database\Capsule;

add_hook('ClientAreaPrimaryNavbar', 1, function (MenuItem $primaryNavbar) {
    $primaryNavbar->addChild('Addons Menu')
        ->setUri('?m=testaddonsmodule')
        ->setOrder(70);
});

add_hook('ClientAdd', 2, function ($vars) {
    echo "<pre>";
    //print_r($vars);
    //die();
    $value = $vars['email'];
    echo $value;
    $client_id = $vars['client_id'];
    echo $client_id;
    $field_id = Capsule::table('tblcustomfields')->where('fieldname', 'LIKE', '%{alternate_email}%')->value('id');
    print_r($field_id);
    $where = [
        "fieldid" => $field_id,
        "relid" => $client_id
    ];
    $check_value = Capsule::table('tblcustomfieldsvalues')->where($where)->first();
    print_r($check_value);
    die;
    if ($check_value) {
        $result = Capsule::table('tblcustomfieldsvalues')->where($where)->update(array('value' => $value));
    }
});
