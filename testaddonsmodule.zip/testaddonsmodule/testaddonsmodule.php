<?php 

use WHMCS\Database\Capsule;
use WHMCS\Module\Addon\TestAddonsModule\Admin\AdminDispatcher;
use WHMCS\Module\Addon\TestAddonsModule\Client\ClientDispatcher;
use WHMCS;

function testaddonsmodule_config()
{
    return [

        'name' => 'Test Addons Module',
        'description' => 'This module provides an example WHMCS Addon Module'
            . ' which can be used as a basis for building a custom addon module.',
        'author' => 'WHMCS',
        'language' => 'english',
        'version' => '1.0',
        'fields' => [
            'Text Field Name' => [
                'FriendlyName' => 'Text Field Name',
                'Type' => 'text',
                'Size' => '25',
                'Default' => 'Default value',
                'Description' => 'Description goes here',
            ],
            'Password Field Name' => [
                'FriendlyName' => 'Password Field Name',
                'Type' => 'password',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter secret value here',
            ],
            'table_delete' => [
                'FriendlyName' => 'Table delete or not?',
                'Type' => 'yesno',
                'Description' => 'Tick for not delete',
            ],
            'Dropdown Field Name' => [
                'FriendlyName' => 'Dropdown Field Name',
                'Type' => 'dropdown',
                'Options' => [
                    'option1' => 'Display Value 1',
                    'option2' => 'Second Option',
                    'option3' => 'Another Option',
                ],
                'Default' => 'option2',
                'Description' => 'Choose one',
            ],
            'Radio Field Name' => [
                'FriendlyName' => 'Radio Field Name',
                'Type' => 'radio',
                'Options' => 'First Option,Second Option,Third Option',
                'Default' => 'Third Option',
                'Description' => 'Choose your option!',
            ],
            'Textarea Field Name' => [
                'FriendlyName' => 'Textarea Field Name',
                'Type' => 'textarea',
                'Rows' => '3',
                'Cols' => '60',
                'Default' => 'A default value goes here...',
                'Description' => 'Freeform multi-line text input field',
            ],
        ]
    ];
}

function testaddonsmodule_activate()
{
    try {
        if(!Capsule::schema()->hasTable('mod_addonexample')){
            Capsule::schema()
            ->create(
                'mod_addonexample',
                function ($table) {
                    $table->increments('id');
                    $table->text('demo');
                    $table->string('name');
                    $table->integer('serial_number');
                    $table->boolean('is_required');
                    $table->timestamps();
                }
            );
        }
        return [
            'status' => 'success',
            'description' => 'This is a demo module only. '
                . 'In a real module you might report a success or instruct a '
                    . 'user how to get started with it here.',
        ];
    } catch (\Exception $e) {
        return [
            'status' => "error",
            'description' => 'Unable to create mod_addonexample: ' . $e->getMessage(),
        ];
    }
}

function testaddonsmodule_deactivate()
{   
    $where = [
        "module" => 'testaddonsmodule',
        "setting" => 'table_delete'
    ];

    $data = Capsule::table('tbladdonmodules')->where($where)->first();
    
    try {
        if(!$data->value){
            Capsule::schema()
            ->dropIfExists('mod_addonexample');
        }
        return [
            'status' => 'success',
            'description' => 'This is a demo module only. '
                . 'In a real module you might report a success here.',
        ];
    } catch (\Exception $e) {
        return [
            "status" => "error",
            "description" => "Unable to drop mod_addonexample: {$e->getMessage()}",
        ];
    }
}

function testaddonsmodule_output($vars)
{   
    $whmcs = WHMCS\Application::getInstance();
    
    $action = !empty($whmcs->get_req_var("action")) ? $whmcs->get_req_var("action") : 'dasboard';
    $dispatcher = new AdminDispatcher();
    $dispatcher->dispatch($action, $vars);
}

function testaddonsmodule_clientarea($vars)
{   

    $action = isset($_REQUEST['action']) ? $_REQUEST['action'] : 'dashboard';

    $dispatcher = new ClientDispatcher();
    return $dispatcher->dispatch($action, $vars);
}