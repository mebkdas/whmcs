$(document).ready(function () {
    $("#clientSelect").click(function () {
        var checkAll = $("#clientSelect").prop('checked');
        if (checkAll) {
            $(".clientOption").prop("checked", true);
        } else {
            $(".clientOption").prop("checked", false);
        }
    });

    $('#client_list').DataTable({

        columnDefs: [{
            'targets': [0],
            'orderable': false,
        }],
    });
});